import 'bangun_datar.dart';

class lingkaran extends bangun_datar {
  double jari = 7.0;

  double luas() => 3.14 * jari * jari;
  double keliling() => 2 * 3.14 * jari;
}
