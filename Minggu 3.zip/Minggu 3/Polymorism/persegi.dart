import 'bangun_datar.dart';

class persegi extends bangun_datar {
  double sisi = 5;

  double luas() => sisi * sisi;
  double keliling() => 4 * sisi;
}
