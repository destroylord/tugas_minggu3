class employee {
  late String id;
  late String name;
  late String departemen;
}
