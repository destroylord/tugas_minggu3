import 'titan.dart';

class armor_titan extends titan {
  String terjang() => "dush..dush..";
}
