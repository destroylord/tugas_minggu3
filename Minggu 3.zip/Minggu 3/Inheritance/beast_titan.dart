import 'titan.dart';

class beast_titan extends titan {
  String lempar() => "wush..wush..";
}
