import 'titan.dart';

class attack_titan extends titan {
  String punch() => "blam..blam..";
}
