import 'titan.dart';

class human extends titan {
  String killAlltitan() => "Sasageyo.. Shinzo Sasageyo..";
}
